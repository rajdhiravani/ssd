<!DOCTYPE html>
<html lang="en">
  <head>
    <meta
      name="facebook-domain-verification"
      content="e8it17fmwurl2fgxl2gkcn37hrpxnp"
    />
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script>
      (function (i, s, o, g, r, a, m) {
        i["GoogleAnalyticsObject"] = r;
        (i[r] =
          i[r] ||
          function () {
            (i[r].q = i[r].q || []).push(arguments);
          }),
          (i[r].l = 1 * new Date());
        (a = s.createElement(o)), (m = s.getElementsByTagName(o)[0]);
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m);
      })(
        window,
        document,
        "script",
        "//www.google-analytics.com/analytics.js",
        "ga"
      );

      ga("create", "UA-190588626-1", "auto");
      ga("send", "pageview");
    </script>

    <!-- Hotjar Tracking Code for https://riidl.org/riidlacademy -->
    <script>
      (function (h, o, t, j, a, r) {
        h.hj =
          h.hj ||
          function () {
            (h.hj.q = h.hj.q || []).push(arguments);
          };
        h._hjSettings = { hjid: 2312793, hjsv: 6 };
        a = o.getElementsByTagName("head")[0];
        r = o.createElement("script");
        r.async = 1;
        r.src = t + h._hjSettings.hjid + j + h._hjSettings.hjsv;
        a.appendChild(r);
      })(window, document, "https://static.hotjar.com/c/hotjar-", ".js?sv=");
    </script>

    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
      var Tawk_API = Tawk_API || {},
        Tawk_LoadStart = new Date();
      (function () {
        var s1 = document.createElement("script"),
          s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = "https://embed.tawk.to/605a2fb7067c2605c0bb80ce/1f1g4kpgk";
        s1.charset = "UTF-8";
        s1.setAttribute("crossorigin", "*");
        s0.parentNode.insertBefore(s1, s0);
      })();
    </script>
    <!--End of Tawk.to Script-->

    <!-- Global site tag (gtag.js) - Google Ads: 420037031 -->
    <script
      async
      src="https://www.googletagmanager.com/gtag/js?id=AW-420037031"
    ></script>

    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag() {
        dataLayer.push(arguments);
      }
      gtag("js", new Date());

      gtag("config", "AW-420037031");
    </script>

    <!-- Facebook Pixel Code -->
    <script>
      !(function (f, b, e, v, n, t, s) {
        if (f.fbq) return;
        n = f.fbq = function () {
          n.callMethod
            ? n.callMethod.apply(n, arguments)
            : n.queue.push(arguments);
        };
        if (!f._fbq) f._fbq = n;
        n.push = n;
        n.loaded = !0;
        n.version = "2.0";
        n.queue = [];
        t = b.createElement(e);
        t.async = !0;
        t.src = v;
        s = b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t, s);
      })(
        window,
        document,
        "script",
        "https://connect.facebook.net/en_US/fbevents.js"
      );
      fbq("init", "482052489844969");
      fbq("track", "PageView");
    </script>

    <noscript>
      <img
        height="1"
        width="1"
        style="display: none"
        src="https://www.facebook.com/tr?id=482052489844969&ev=PageView&noscript=1"
      />
    </noscript>

    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta
      name="description"
      content="Somaiya School of Design is leading the way to reinvent Design education through its 4 year undergraduate program - Bachelor of Design in sustainable Product Design."
    />
    <meta
      name="keywords"
      content="what is product design, what does a product designer do, what is product design and development, what is product design engineering, UCEED, NIFT, Design Entrance Exam, Bachelor of Design, DAT, NID, IDC IIT B, Somaiya University, Undergraduate, Riidl academy, Design program, design degree, product design, AR, VR, Bio design, Fab lab, international, Visual learning, experiential learning"
    />
    <link rel="canonical" href="https://riidl.org/riidlacademy/index.html" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
    />
    <link rel="shortcut icon" href="./img/favicon.png" type="image/x-icon" />
    <link rel="stylesheet" href="./style.css" />
    <title>Somaiya School of Design - An institution without boundaries</title>
  </head>
  <body>
    <nav id="navbar">
      <div class="logoStrip">
        <a href="">
          <img src="./img/ssd logo new.png" alt="riidl Academy" />
        </a>
        <ul>
          <li>
            <div class="dropdown">
              <a href="./about/index.html">About School of Design</a>
              <div class="dropdown-content">
                <a href="./index.html">Home</a>
                <a href="./about/index.html">Introduction to Somaiya School of Design</a>
                <a href="./about/vision.html">Vision and Mission</a>
                <a href="./about/organization.html">Organizational Structure</a>
                <a href="./about/advisory.html">Academic Advisory Board</a>
              </div>
            </div>
          </li>
          <li>
            <div class="dropdown">
              <a href="./bdes/index.html">BDes Academics</a>
              <div class="dropdown-content">
                <a href="./bdes/index.html">Introduction to BDes Program</a>
                <a href="./bdes/journey.html">4 Year Journey</a>
                <a href="./bdes/pillars.html">Curriculum Framework</a>
                <a href="./bdes/block.html">Block Plan</a>
                <a href="./bdes/education.html">Education Value System</a>
                <a href="./bdes/outcomes.html">Program Outcomes</a>
                <a href="./bdes/faculty.html">Our Faculty</a>
                <a href="./bdes/labs.html">Our Labs</a>
                <a href="./bdes/after.html">Life after Bachelor of Design</a>
                <a href="./bdes/board.html">Board of Studies</a>
              </div>
            </div>
          </li>
          <li>
            <div class="dropdown">
              <a href="./collaborations/index.html">Collaborations</a>
              <div class="dropdown-content">
                <a href="./collaborations/index.html">Our Partners</a>
                <a href="./collaborations/exchange.html">Exchange Program</a>
                <a href="./collaborations/grants.html">Grants</a>
              </div>
            </div>
          </li>
          <li>
            <div class="dropdown">
              <a href="./student/build.html">Impact</a>
              <div class="dropdown-content">
                <a href="./student/build.html">Product Designs at riidl</a>
                <a href="./student/index.html">Student Life</a>
                <a href="./student/testimonials.html">Testimonials</a>
                <a href="./student/media.html">Media</a>
                <a href="./student/blogs.html">Blogs</a>
              </div>
            </div>
          </li>
          <li>
            <div class="dropdown">
              <a href="./admission/index.html">Admissions</a>
              <div class="dropdown-content">
                <a href="./admission/index.html"
                  >Eligibility & Admission Process</a
                >
                <a href="./admission/dates.html">Important Dates</a>
                <a href="./admission/fees.html">Fee Structure</a>
              </div>
            </div>
          </li>
          <li><a href="./contact/index.html">Contact Us</a></li>
        </ul>
        <img src="./img/STrust.png" alt="Somaiya Trust" />
        <div class="ham" id="navOpenIcon">
          <img src="./img/hamburger.svg" alt="Hamburger" id="navBars" />
          <h4>Menu</h4>
        </div>
      </div>
      <div class="navContent navbarDisappear" id="navContent">
        <div class="logoStrip">
          <a href=""
            ><img src="./img/ssd logo new.png" alt="riidl Academy"
          /></a>
          <img src="./img/STrust.png" alt="Somaiya Trust" />
          <div class="ham" id="navCloseIcon">
            <img src="./img/close.svg" alt="Close" id="navClose" />
            <h4>Close</h4>
          </div>
        </div>
        <div class="navLinks">
          <div class="navLinkColumn">
            <h3><a href="./about/index.html">Somaiya School of Design</a></h3>
            <ul>
              <li><a href="./">Home</a></li>
              <li>
                <a href="./about/index.html">Introduction to Somaiya School of Design</a>
              </li>
              <li><a href="./about/vision.html">Vision and Mission</a></li>
              <li>
                <a href="./about/organization.html">Organizational Structure</a>
              </li>
              <li>
                <a href="./about/advisory.html">Academic Advisory Board</a>
              </li>
            </ul>
          </div>
          <div class="navLinkColumn">
            <h3>
              <a href="./bdes/index.html">Bachelor of Design Academics</a>
            </h3>
            <ul>
              <li>
                <a href="./bdes/index.html">Introduction to BDes Program</a>
              </li>
              <li><a href="./bdes/journey.html">4 Year Journey</a></li>
              <li>
                <a href="./bdes/pillars.html"> Curriculum Framework </a>
              </li>
              <li><a href="./bdes/block.html">Block Plan</a></li>
              <li>
                <a href="./bdes/education.html">Education Value System</a>
              </li>
              <li><a href="./bdes/outcomes.html">Program Outcomes</a></li>
              <li><a href="./bdes/faculty.html">Our Faculty</a></li>
              <li><a href="./bdes/labs.html">Our Labs</a></li>
              <li>
                <a href="./bdes/after.html">Life after Bachelor of Design</a>
              </li>
              <li><a href="./bdes/board.html">Board of Studies</a></li>
            </ul>
          </div>
          <div class="navLinkColumn">
            <h3><a href="./collaborations/index.html">Collaborations</a></h3>
            <ul>
              <li><a href="./collaborations/index.html">Our Partners</a></li>
              <li>
                <a href="./collaborations/exchange.html">Exchange Program</a>
              </li>
              <li><a href="./collaborations/grants.html">Grants</a></li>
            </ul>
          </div>
          <div class="navLinkColumn">
            <h3>
              <a href="./student/build.html">Impact</a>
            </h3>
            <ul>
              <li>
                <a href="./student/build.html">Product Designs at riidl</a>
              </li>
              <li><a href="./student/index.html">Student Life</a></li>
              <li><a href="./student/testimonials.html">Testimonials</a></li>
              <li><a href="./student/media.html">Media</a></li>
              <li><a href="./student/blogs.html">Blogs</a></li>
            </ul>
          </div>
          <div class="navLinkColumn">
            <h3><a href="./admission/index.html">Admissions</a></h3>
            <ul>
              <li>
                <a href="./admission/index.html"
                  >Eligibility & Admission Process</a
                >
              </li>
              <li>
                <a href="./admission/dates.html">Important Dates</a>
              </li>
              <li><a href="./admission/fees.html">Fee Structure</a></li>
            </ul>
          </div>
        </div>
        <div class="navContact">
          <h2><a href="./contact/index.html">Contact Us</a></h2>
          <p>
            Subscribe to our mailing list to keep up with the events and
            important dates.
          </p>
          <form action="">
            <input type="text" placeholder="Enter your Email Address" />
            <button>Sign Up <img src="./img/arrow.svg" alt="Arrow" /></button>
          </form>
        </div>
      </div>
    </nav>

    <div class="landingContainer">
      <div class="leftStrip"></div>
      <div class="bottomStrip"></div>
      <div class="bottomSecondStrip"></div>
      <div class="illustrationContainer">
        <img src="./img/landing.png" alt="Illustration" />
        <div class="videoSection">
          <iframe
            src="https://www.youtube.com/embed/kpT6W5iWjp4"
            title="YouTube video player"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
          ></iframe>
        </div>
      </div>
      <div class="landingText">
        <div class="landingSection">
          <h1>
            Somaiya School of Design is an institution without boundaries.
            <br />
            <span>
              We offer Bachelor of Design - 4 year, full time Undergraduate
              Degree Program.
            </span>
            <span>
              Join us to build solutions for our people and our planet through
              Sustainable Product Design.
            </span>
          </h1>

          <div class="nextLinks">
            <a href="https://forms.gle/g7KbhHA3Hu9fv8Ls5" target="_blank">
              <p>Enquire Now</p>
              <img src="./img/shortArrow.svg" alt="Arrow" />
            </a>
            <a href="https://forms.gle/rqqH6aGMnoXfSY3w5" target="_blank">
              <p>Apply Now</p>
              <img src="./img/shortArrow.svg" alt="Arrow" />
            </a>
          </div>
        </div>

        <div class="linksList">
          <a>
            <img src="./img/shortArrow.svg" alt="Arrow" />
            <p>30 Students per batch - 4 years of Experiential Learning</p>
          </a>
          <a href="./bdes/index.html">
            <img src="./img/shortArrow.svg" alt="Arrow" />
            <p>
              <span>Product Design</span> focusing on Functionality, Aesthetics
              and Sustainability
            </p>
          </a>
          <a href="./student/build.html">
            <img src="./img/shortArrow.svg" alt="Arrow" />
            <p>
              <span>Build</span> Tangible solutions, screen or graphical
              solutions & service oriented solutions
            </p>
          </a>
          <a href="./bdes/pillars.html">
            <img src="./img/shortArrow.svg" alt="Arrow" />
            <p>
              Evolving <span>curriculum</span> based on Design, Technology,
              Business and Humanities
            </p>
          </a>
          <a href="./bdes/block.html">
            <img src="./img/shortArrow.svg" alt="Arrow" />
            <p>
              <span>Block plan</span> - Unique model that facilitates deeper
              learning engagement
            </p>
          </a>
          <a href="./bdes/faculty.html">
            <img src="./img/shortArrow.svg" alt="Arrow" />
            <p>
              Diverse <span>Faculty</span> from across the globe - experts who
              are passionate about teaching
            </p>
          </a>
          <a href="./bdes/labs.html">
            <img src="./img/shortArrow.svg" alt="Arrow" />
            <p>
              World class <span>laboratories</span> to build prototypes -
              FABLAB, SMAC lab, BIOLAB, XR LAB
            </p>
          </a>
          <a href="./collaborations/index.html">
            <img src="./img/shortArrow.svg" alt="Arrow" />
            <p>
              Strategic <span>Partnerships</span>, field Visits, projects &
              internships for experiential learning
            </p>
          </a>
          <a href="./collaborations/exchange.html">
            <img src="./img/shortArrow.svg" alt="Arrow" />
            <p>
              International Student <span>Exchange programs</span> at
              universities across Europe and USA
            </p>
          </a>
          <a href="./collaborations/grants.html">
            <img src="./img/shortArrow.svg" alt="Arrow" />
            <p><span>Grants</span> to support Innovation</p>
          </a>
          <a href="./student/index.html">
            <img src="./img/shortArrow.svg" alt="Arrow" />
            <p>
              Thriving <span>Design and Innovation communities</span> to stay
              connected & inspired
            </p>
          </a>
          <a href="./bdes/after.html">
            <img src="./img/shortArrow.svg" alt="Arrow" />
            <p>
              <span>Superpowers</span> for our ChangeMakers: Adaptability,
              Accountability and Altruism
            </p>
          </a>
          <a href="./bdes/after.html">
            <img src="./img/shortArrow.svg" alt="Arrow" />
            <p>Bright future as <span>ChangeMakers</span></p>
          </a>
          <a href="./student/testimonials.html">
            <img src="./img/shortArrow.svg" alt="Arrow" />
            <p><span>Testimonials:</span> Hear from our Community Members</p>
          </a>
          <p>One Incredible Experience awaits you!</p>
        </div>
      </div>
    </div>

    <div class="footerContainer">
      <div class="footerContent">
        <div class="contactLinks">
          <p>Contact Us via</p>
          <div class="contactInfo">
            <a href="mailto:riidlacademy@somaiya.edu" target="_blank">Email</a>
            <a
              href="https://web.whatsapp.com/send?phone=+919920052361"
              target="_blank"
              >WhatsApp</a
            >
          </div>
          <div class="contactInfo">
            <a href="https://www.facebook.com/riidlacademy/" target="_blank">
              <i class="fa fa-facebook"></i>
            </a>
            <a href="https://www.instagram.com/riidlacademy" target="_blank">
              <i class="fa fa-instagram"></i>
            </a>
            <a href="http://linkedin.com/company/riidlacademy" target="_blank">
              <i class="fa fa-linkedin"></i>
            </a>
            <a href="https://twitter.com/riidlacademy" target="_blank">
              <i class="fa fa-twitter"></i>
            </a>
          </div>
        </div>
        <div class="contactJoiningLinks">
          <p>Join us for our mission of building sustainable solutions</p>
          <div class="nextLinks">
            <a href="https://forms.gle/g7KbhHA3Hu9fv8Ls5" target="_blank">
              <p>Enquire Now</p>
              <img src="./img/shortArrow.svg" alt="Arrow" />
            </a>
            <a href="https://forms.gle/rqqH6aGMnoXfSY3w5" target="_blank">
              <p>Apply Now</p>
              <img src="./img/shortArrow.svg" alt="Arrow" />
            </a>
          </div>
        </div>
        <p id="contactCopyright">&copy; Somaiya School of Design 2021</p>
      </div>
      <button onclick="window.scrollTo(0,0)">Top</button>
    </div>

    <script>
      const bars = document.getElementById("navOpenIcon");
      const close = document.getElementById("navCloseIcon");
      const navbar = document.getElementById("navContent");
      const nav = document.getElementById("navbar");

      bars.onclick = function () {
        navbar.classList.remove("navbarDisappear");
        navbar.classList.add("navbarAppear");
        nav.style.height = "100vh";
      };

      close.onclick = function () {
        navbar.classList.remove("navbarAppear");
        navbar.classList.add("navbarDisappear");
        nav.style.height = "100px";
      };
    </script>
  </body>
</html>
